package data;

import java.util.regex.Pattern;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class DataClass {
	
	private String name;
	private float bal;
	private long phone;
	@Id
	private long account;
	public static String transaction[]=new String[5];
	public DataClass(String transaction) {
		int i=0;
		DataClass.transaction[i]=transaction;
		i++;
	}

	public DataClass() {
		// TODO Auto-generated constructor stub
	}
	//getters and setters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public float getBal() {
		return bal;
	}
	public void setBal(float bal) {
		this.bal = bal;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public long getAccount() {
		return account;
	}
	public void setAccount(long account) {
		this.account = account;
	}
	
	
	
	
	
}